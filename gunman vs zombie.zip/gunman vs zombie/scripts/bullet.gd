extends Area2D

@export var speed: float = 600.0
@export var lifetime: float = 2.0

var vel = Vector2.ZERO

func _ready():
    vel = Vector2.RIGHT.rotated(rotation) * speed
    $Collision.connect("body_entered", Callable(self, "_on_body_entered"))
    set_process(true)
    yield(get_tree().create_timer(lifetime), "timeout")
    queue_free()

func _process(delta):
    position += vel * delta

func _on_body_entered(body):
    if body.is_in_group("zombies"):
        if body.has_method("damage"):
            body.damage(1)
        queue_free()
