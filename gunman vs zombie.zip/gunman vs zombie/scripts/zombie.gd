extends Node2D

@export var speed: float = 80.0
var hp: int = 2
var player_ref: Node2D = null

func _ready():
    add_to_group("zombies")
    set_process(true)
    update()

func _process(delta):
    if not player_ref or not is_instance_valid(player_ref):
        player_ref = get_tree().get_root().get_node("Main/Player")
    if player_ref and is_instance_valid(player_ref):
        var dir = (player_ref.global_position - global_position)
        if dir.length() > 8:
            global_position += dir.normalized() * speed * delta
            rotation = dir.angle()

func damage(amount: int):
    hp -= amount
    if hp <= 0:
        queue_free()

func _draw():
    draw_circle(Vector2.ZERO, 12, Color(0.6,0.2,0.2))
