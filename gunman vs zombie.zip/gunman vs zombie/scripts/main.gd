extends Node2D

@export var zombie_scene: PackedScene
@export var player_scene: PackedScene
@export var bullet_scene: PackedScene

func _ready():
    var player = player_scene.instantiate()
    player.name = "Player"
    add_child(player)
    player.bullet_scene = bullet_scene
    $SpawnTimer.connect("timeout", Callable(self, "_on_spawn_timer_timeout"))
    $SpawnTimer.start()

func _on_spawn_timer_timeout():
    var z = zombie_scene.instantiate()
    var rw = 800
    var rh = 600
    var edge = randi() % 4
    var x = 0
    var y = 0
    match edge:
        0:
            x = rand_range(-50, rw+50)
            y = -60
        1:
            x = rand_range(-50, rw+50)
            y = rh+60
        2:
            x = -60
            y = rand_range(-50, rh+50)
        3:
            x = rw+60
            y = rand_range(-50, rh+50)
    z.global_position = Vector2(x,y)
    add_child(z)

func _input(event):
    if event is InputEventKey and event.pressed and event.scancode == Key.ESCAPE:
        get_tree().quit()
