extends Node2D

@export var speed: float = 240.0
@export var bullet_scene: PackedScene

func _ready():
    set_process(true)
    update()

func _process(delta):
    var input_vec = Vector2.ZERO
    input_vec.y = int(Input.is_action_pressed("ui_down")) - int(Input.is_action_pressed("ui_up"))
    input_vec.x = int(Input.is_action_pressed("ui_right")) - int(Input.is_action_pressed("ui_left"))
    if input_vec != Vector2.ZERO:
        input_vec = input_vec.normalized()
        position += input_vec * speed * delta
    var mouse_pos = get_global_mouse_position()
    rotation = (mouse_pos - global_position).angle()
    if Input.is_action_just_pressed("shoot"):
        shoot()

func shoot():
    if not bullet_scene:
        return
    var b = bullet_scene.instantiate()
    b.global_position = global_position
    b.rotation = rotation
    get_tree().get_root().get_node("Main/Zombies").get_parent().add_child(b)

func _draw():
    draw_circle(Vector2.ZERO, 12, Color(0.2,0.6,1))
    var dir = Vector2.RIGHT.rotated(rotation) * 16
    draw_line(Vector2.ZERO, dir, Color(1,1,1), 2)
